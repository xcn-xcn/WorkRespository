﻿using AlgoControlLibrary.AlgoBaseFactory;
using OpenCvSharp;
using SmartMore.ViMo;
using SmoreControlLibrary;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Reflection;
using System.Runtime.Remoting.Contexts;
using System.Text;
using System.Text.Json.Nodes;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AlgoControlLibrary.VimoAlgo
{

    public class AlgoRunOutput
    {
        public Mat mask;
        public Dictionary<string, int> Dicdefect;
    }

    public abstract class VimoManager
    {


        public abstract EnumReturnVal Init(AlgoInitInput algoinput);


        public abstract EnumReturnVal Run(AlgoRunInput RunInput, out AlgoRunOutput rsps);


        public abstract EnumReturnVal Free();
        

    }
}
