﻿using OpenCvSharp;
using SmartMore.ViMo;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AlgoControlLibrary.AlgoBaseFactory
{

    public enum EnumReturnVal
    {
        Return_OK=0,
        Return_Fail=1,
    
    }


    public class AlgoInitInput
    {

        public string modelPath = @"./model.vimosln"; // replace with your `model.vimosln` path
        public string moduleId = "5";                 // get module id from `index.html`
        public bool useGpu = false;                   // whether to use gpu for inference
        public int deviceId = 0;                      // GPU device id, ignore if use_gpu == false
        public AlgoInitInput() { 
        
        }
    }

    public class AlgoRunInput 
    {
        public Mat SourceImg=null;
        public string config="";
       public AlgoRunInput() { }    
    }

   



    public interface IAlgo
    {
        #region property

        string Name { get; set; }
        string MoudleID { get; set; }
        #endregion


        #region Method
        EnumReturnVal Init(AlgoInitInput algoinput);

        EnumReturnVal Run<T>(AlgoRunInput RunInput, out ResponseList<T> rsps) where T : SmartMore.ViMo.Response;

        EnumReturnVal Free();

        #endregion
    }
}
