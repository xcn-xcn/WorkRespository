﻿using AlgoControlLibrary.AlgoBaseFactory;
using OpenCvSharp;
using SmartMore.ViMo;
using SmoreControlLibrary;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Reflection;
using System.Runtime.Remoting.Contexts;
using System.Text;
using System.Text.Json.Nodes;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AlgoControlLibrary.VimoAlgo
{
    public class VimoSegmentManager:VimoManager
    {
        IAlgo algo=null;
        public VimoSegmentManager() {

            algo = new VimoFactory().CreateVimo();
        }


        #region override
        public override EnumReturnVal Init(AlgoInitInput algoinput)
        {
            try
            {
                return algo.Init(algoinput);               
            }
            catch (Exception ex)
            {
                SMLogWindow.OutLog($"{ex.ToString()}", Color.Green);
                return EnumReturnVal.Return_Fail;
            }
        }

        public override EnumReturnVal Run(AlgoRunInput RunInput, out AlgoRunOutput rsps)
        {
            SMLogWindow.OutLog($"init:start", Color.Green);
            AlgoRunOutput _rsps = null;
            try
            {
                algo.Run(RunInput, out ResponseList<SegmentationResponse> algorunOutput);
                rsps = _rsps;
                return EnumReturnVal.Return_OK;
            }
            catch (Exception ex)
            {
                rsps = null;
                return EnumReturnVal.Return_Fail;
            }
        }

        public override EnumReturnVal Free()
        {
            try
            {
                algo.Free();
                return EnumReturnVal.Return_OK;
            }
            catch
            {

                return EnumReturnVal.Return_Fail;
            }
        }
        #endregion


        #region Method


        #endregion

    }
}
