﻿namespace SmoreVision
{
    partial class FormMain
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要修改
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.smLogWindow = new SmoreControlLibrary.SMLogWindow();
            this.smInfoWindow1 = new SmoreControlLibrary.SMInfo.SMInfoWindow();
            this.smDataWindow1 = new SmoreControlLibrary.SMData.SMDataWindow();
            this.tableLayoutPanelMainHome = new System.Windows.Forms.TableLayoutPanel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.button1 = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.smButtonRun = new SmoreControlLibrary.SMButton();
            this.panel4 = new System.Windows.Forms.Panel();
            this.label2 = new System.Windows.Forms.Label();
            this.smButtonOCR = new SmoreControlLibrary.SMButton();
            this.smImageWindow1 = new SmoreControlLibrary.SMImage.SMImageWindow();
            this.tableLayoutPanel1.SuspendLayout();
            this.tableLayoutPanelMainHome.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel4.SuspendLayout();
            this.SuspendLayout();
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 1;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel1.Controls.Add(this.smLogWindow, 0, 2);
            this.tableLayoutPanel1.Controls.Add(this.smInfoWindow1, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.smDataWindow1, 0, 1);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Right;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(697, 30);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 3;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 200F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(356, 640);
            this.tableLayoutPanel1.TabIndex = 1;
            // 
            // smLogWindow
            // 
            this.smLogWindow.Dock = System.Windows.Forms.DockStyle.Fill;
            this.smLogWindow.Location = new System.Drawing.Point(3, 443);
            this.smLogWindow.LogPathValue = null;
            this.smLogWindow.Name = "smLogWindow";
            this.smLogWindow.Size = new System.Drawing.Size(350, 194);
            this.smLogWindow.TabIndex = 0;
            // 
            // smInfoWindow1
            // 
            this.smInfoWindow1.BatchNumber = "1";
            this.smInfoWindow1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.smInfoWindow1.EquipmentNumber = "1";
            this.smInfoWindow1.Location = new System.Drawing.Point(3, 3);
            this.smInfoWindow1.ModelDate = "20220714";
            this.smInfoWindow1.ModelVersion = "V1.0";
            this.smInfoWindow1.Name = "smInfoWindow1";
            this.smInfoWindow1.ProductModel = "F-609127.60";
            this.smInfoWindow1.Size = new System.Drawing.Size(350, 214);
            this.smInfoWindow1.TabIndex = 1;
            // 
            // smDataWindow1
            // 
            this.smDataWindow1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.smDataWindow1.Location = new System.Drawing.Point(3, 223);
            this.smDataWindow1.Name = "smDataWindow1";
            this.smDataWindow1.NGNum = 0;
            this.smDataWindow1.OKNum = 0;
            this.smDataWindow1.RateNum = 0D;
            this.smDataWindow1.Size = new System.Drawing.Size(350, 214);
            this.smDataWindow1.TabIndex = 2;
            this.smDataWindow1.TotalNum = 0;
            this.smDataWindow1.ClearData += new System.EventHandler(this.smDataWindow1_ClearData);
            // 
            // tableLayoutPanelMainHome
            // 
            this.tableLayoutPanelMainHome.ColumnCount = 2;
            this.tableLayoutPanelMainHome.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanelMainHome.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanelMainHome.Controls.Add(this.panel3, 0, 0);
            this.tableLayoutPanelMainHome.Controls.Add(this.smImageWindow1, 0, 1);
            this.tableLayoutPanelMainHome.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanelMainHome.Location = new System.Drawing.Point(0, 30);
            this.tableLayoutPanelMainHome.Name = "tableLayoutPanelMainHome";
            this.tableLayoutPanelMainHome.RowCount = 3;
            this.tableLayoutPanelMainHome.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 46F));
            this.tableLayoutPanelMainHome.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanelMainHome.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanelMainHome.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanelMainHome.Size = new System.Drawing.Size(697, 640);
            this.tableLayoutPanelMainHome.TabIndex = 3;
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(227)))), ((int)(((byte)(231)))));
            this.tableLayoutPanelMainHome.SetColumnSpan(this.panel3, 2);
            this.panel3.Controls.Add(this.button1);
            this.panel3.Controls.Add(this.label1);
            this.panel3.Controls.Add(this.smButtonRun);
            this.panel3.Controls.Add(this.panel4);
            this.panel3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel3.Location = new System.Drawing.Point(3, 3);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(691, 40);
            this.panel3.TabIndex = 0;
            this.panel3.Paint += new System.Windows.Forms.PaintEventHandler(this.panel3_Paint);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(3, 7);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(23, 23);
            this.button1.TabIndex = 3;
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // label1
            // 
            this.label1.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("微软雅黑", 10.5F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label1.Location = new System.Drawing.Point(445, 11);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(65, 19);
            this.label1.TabIndex = 2;
            this.label1.Text = "自动运行";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // smButtonRun
            // 
            this.smButtonRun.BackColor = System.Drawing.Color.Transparent;
            this.smButtonRun.BtnBackColor = System.Drawing.Color.Transparent;
            this.smButtonRun.BtnFont = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.smButtonRun.BtnForeColor = System.Drawing.Color.Black;
            this.smButtonRun.BtnImage = global::SmoreVision.Properties.Resources.auto_off;
            this.smButtonRun.BtnText = null;
            this.smButtonRun.ConerRadius = 24;
            this.smButtonRun.Dock = System.Windows.Forms.DockStyle.Right;
            this.smButtonRun.Enabled = false;
            this.smButtonRun.FillColor = System.Drawing.Color.Transparent;
            this.smButtonRun.IsRadius = false;
            this.smButtonRun.IsShowRect = false;
            this.smButtonRun.IsShowTips = false;
            this.smButtonRun.Location = new System.Drawing.Point(526, 0);
            this.smButtonRun.Margin = new System.Windows.Forms.Padding(4);
            this.smButtonRun.Name = "smButtonRun";
            this.smButtonRun.RectColor = System.Drawing.Color.FromArgb(((int)(((byte)(220)))), ((int)(((byte)(220)))), ((int)(((byte)(220)))));
            this.smButtonRun.RectWidth = 1;
            this.smButtonRun.Size = new System.Drawing.Size(35, 40);
            this.smButtonRun.TabIndex = 0;
            this.smButtonRun.TabStop = false;
            this.smButtonRun.TipsText = "";
            this.smButtonRun.BtnClick += new System.EventHandler(this.smButtonRun_BtnClick);
            // 
            // panel4
            // 
            this.panel4.Controls.Add(this.label2);
            this.panel4.Controls.Add(this.smButtonOCR);
            this.panel4.Dock = System.Windows.Forms.DockStyle.Right;
            this.panel4.Location = new System.Drawing.Point(561, 0);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(130, 40);
            this.panel4.TabIndex = 1;
            // 
            // label2
            // 
            this.label2.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("微软雅黑", 10.5F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label2.Location = new System.Drawing.Point(23, 11);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(39, 19);
            this.label2.TabIndex = 3;
            this.label2.Text = "OCR";
            // 
            // smButtonOCR
            // 
            this.smButtonOCR.BackColor = System.Drawing.Color.Transparent;
            this.smButtonOCR.BtnBackColor = System.Drawing.Color.Transparent;
            this.smButtonOCR.BtnFont = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.smButtonOCR.BtnForeColor = System.Drawing.Color.Black;
            this.smButtonOCR.BtnImage = global::SmoreVision.Properties.Resources.auto_off;
            this.smButtonOCR.BtnText = null;
            this.smButtonOCR.ConerRadius = 24;
            this.smButtonOCR.Dock = System.Windows.Forms.DockStyle.Right;
            this.smButtonOCR.Enabled = false;
            this.smButtonOCR.FillColor = System.Drawing.Color.Transparent;
            this.smButtonOCR.IsRadius = false;
            this.smButtonOCR.IsShowRect = false;
            this.smButtonOCR.IsShowTips = false;
            this.smButtonOCR.Location = new System.Drawing.Point(95, 0);
            this.smButtonOCR.Margin = new System.Windows.Forms.Padding(4);
            this.smButtonOCR.Name = "smButtonOCR";
            this.smButtonOCR.RectColor = System.Drawing.Color.FromArgb(((int)(((byte)(220)))), ((int)(((byte)(220)))), ((int)(((byte)(220)))));
            this.smButtonOCR.RectWidth = 1;
            this.smButtonOCR.Size = new System.Drawing.Size(35, 40);
            this.smButtonOCR.TabIndex = 1;
            this.smButtonOCR.TabStop = false;
            this.smButtonOCR.TipsText = "";
            this.smButtonOCR.BtnClick += new System.EventHandler(this.smButton1_BtnClick);
            // 
            // smImageWindow1
            // 
            this.tableLayoutPanelMainHome.SetColumnSpan(this.smImageWindow1, 2);
            this.smImageWindow1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.smImageWindow1.IamgeWindowCT = "0ms";
            this.smImageWindow1.IamgeWindowRatio = null;
            this.smImageWindow1.IamgeWindowTotal = null;
            this.smImageWindow1.IamgeWindowType = "CLS";
            this.smImageWindow1.ImageWindowName = "CCD15";
            this.smImageWindow1.ImageWindowNG = 0;
            this.smImageWindow1.ImageWindowOK = 0;
            this.smImageWindow1.Location = new System.Drawing.Point(4, 50);
            this.smImageWindow1.Margin = new System.Windows.Forms.Padding(4);
            this.smImageWindow1.Name = "smImageWindow1";
            this.tableLayoutPanelMainHome.SetRowSpan(this.smImageWindow1, 2);
            this.smImageWindow1.ShowManualButton = false;
            this.smImageWindow1.Size = new System.Drawing.Size(689, 586);
            this.smImageWindow1.TabIndex = 4;
            this.smImageWindow1.BtnRunSinglePicClick += new System.EventHandler(this.smImageWindow1_BtnRunSinglePicClick);
            this.smImageWindow1.BtnRunFolderPicClick += new System.EventHandler(this.smImageWindow1_BtnRunFolderPicClick);
            this.smImageWindow1.TriggerCamera += new System.EventHandler(this.smImageWindow1_TriggerCamera);
            // 
            // FormMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1053, 670);
            this.Controls.Add(this.tableLayoutPanelMainHome);
            this.Controls.Add(this.tableLayoutPanel1);
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "FormMain";
            this.Text = "Form1";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.FormMain_FormClosed);
            this.Load += new System.EventHandler(this.FormMain_Load);
            this.Controls.SetChildIndex(this.tableLayoutPanel1, 0);
            this.Controls.SetChildIndex(this.tableLayoutPanelMainHome, 0);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanelMainHome.ResumeLayout(false);
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private SmoreControlLibrary.SMLogWindow smLogWindow;
        private SmoreControlLibrary.SMInfo.SMInfoWindow smInfoWindow1;
        private SmoreControlLibrary.SMData.SMDataWindow smDataWindow1;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanelMainHome;
        private System.Windows.Forms.Panel panel3;
        private SmoreControlLibrary.SMButton smButtonRun;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Label label1;
        private SmoreControlLibrary.SMImage.SMImageWindow smImageWindow1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label2;
        private SmoreControlLibrary.SMButton smButtonOCR;
    }
}

