﻿using Newtonsoft.Json;
using OpenCvSharp;
using SmoreControlLibrary;
using SmoreControlLibrary.SMData;
using SmoreControlLibrary.SMImage;
using SmoreControlLibrary.SMInfo;
using SmoreControlLibrary.SMLog;
using SmoreControlLibrary.SystemConfig;
using SmoreVision.BusinessClass;
using SmoreVision.FunctionClass;
using SmoreVision.HardwareControl;
using SmoreVision.HardwareControlClass;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using WindGoes6.Data;
using static SmoreControlLibrary.SystemConfig.JsonFileParse;
using static SmoreVision.HardwareControl.ImageType;

namespace SmoreVision
{
    public partial class FormMain : FormMainBase
    {
        public const int ERROR_OK = 0;
        public const int ERROR_FAILED = -1;

        private const string CONFIG_FILE_TYPE = "xml";

        private bool BtnRunState = false;
        private bool BtnOCRState = false;

        private XMLConfigParse XMLConfig = new XMLConfigParse();
        private string ConfigFilePath = "";
        private string ErrorInfo = "";
        private int returnValue = 0;

        private SMImageWindow[] m_SMImageWindows = new SMImageWindow[GlobalVariables.GConst.IMAGE_WINDOW_COUNT];
        private HIKCameraControl[] m_HIKCameraControl;
        private ActionRunThread[] m_ActionRunThread;
        private ConnectHeartbeatThread[] m_ConnectHeartbeatThreads;
        private AIRunThread[] m_AIRunThread;
        private AISDKManage m_AISDKManage;
        private SaveImageThread m_SaveImageThread;
        private SiemensPLCControl m_SiemensPLCControl;

        private Task SimplexTask = null;
        private Task SimplexTrigerTask = null;
        private Task MultipleTask = null;
        private bool MultipleTaskRun = false;

        private SaveImage m_SaveImage;

        public FormMain()
        {
            InitializeComponent();
            InitialControlArray();

            Assembly asm = Assembly.GetExecutingAssembly();
            AssemblyDescriptionAttribute asmDesc = (AssemblyDescriptionAttribute)Attribute.GetCustomAttribute(asm, typeof(AssemblyDescriptionAttribute));
            AssemblyCopyrightAttribute asmCpr = (AssemblyCopyrightAttribute)Attribute.GetCustomAttribute(asm, typeof(AssemblyCopyrightAttribute));
            AssemblyCompanyAttribute asmCpn = (AssemblyCompanyAttribute)Attribute.GetCustomAttribute(asm, typeof(AssemblyCompanyAttribute));
            AssemblyConfigurationAttribute asmConfig = (AssemblyConfigurationAttribute)Attribute.GetCustomAttribute(asm, typeof(AssemblyConfigurationAttribute));

            //读取SmoreVisionConfig.xml文件信息
            ConfigFilePath = Path.GetFullPath($"{asmConfig.Configuration}.{CONFIG_FILE_TYPE}");
            if (InitialConfigFile() != ERR_OK)
            {
                Log.Add("加载配置文件失败", Color.Green);
                return;
            }

            Log.Add("加载配置文件成功", Color.Green);

            if (XMLConfig.System.FullScreen)
            {
                this.WinState = FormWindowState.Maximized;
            }
            else
            {
                this.WinState = FormWindowState.Normal;
            }

            this.ProjectName = XMLConfig.System.ProjectName;
        }

        private List<FileInfo> GetFamilyFiles(FileSystemInfo familyPath)
        {
            List<FileInfo> familyFileList = new List<FileInfo>();
            //判断目录是否存在
            if (!familyPath.Exists) return null;
            DirectoryInfo dir = familyPath as DirectoryInfo;
            //不是目录则返回
            if (dir == null) return null;
            //将文件后缀为rfa的文件添加进列表
            familyFileList.AddRange(dir.GetFiles("*.json"));
            //递归遍历文件夹
            foreach (DirectoryInfo dinfo in dir.GetDirectories())
            {
                familyFileList.AddRange(GetFamilyFiles(dinfo));
            }

            return familyFileList;
        }


        private void FormMain_Load(object sender, EventArgs e)
        {
            m_HIKCameraControl = new HIKCameraControl[GlobalVariables.GConst.STATION_COUNT];
            m_ActionRunThread = new ActionRunThread[GlobalVariables.GConst.STATION_COUNT];
            m_ConnectHeartbeatThreads = new ConnectHeartbeatThread[GlobalVariables.GConst.STATION_COUNT];
            m_AIRunThread = new AIRunThread[GlobalVariables.GConst.STATION_COUNT];
            m_SaveImageThread = new SaveImageThread(XMLConfig);
            m_AISDKManage = new AISDKManage(ref XMLConfig);
            m_SiemensPLCControl = new SiemensPLCControl(ref XMLConfig);
            smImageWindow1.ShowManualButton = true;
            //smImageWindow2.ShowManualButton = true;
            smImageWindow1.InitData();
            //smImageWindow2.InitData();

            //m_SaveImageThread.StartThread(); //临时启动存图线程

            //string pathTemp = Application.StartupPath + "\\Formula";
            //List<FileInfo> m_fileinfo = GetFamilyFiles(new DirectoryInfo(pathTemp));

            //设备信息更新
            smInfoWindow1.Init();
            this.smInfoWindow1.m_TriDevice += UpdateDevice;


            returnValue = m_AISDKManage.Init();
            if (returnValue != ERROR_OK)
            {
                Log.Add($"AI SDK 初始化失败!", Color.Red);
                return;
            }
            else
            {
                Log.Add($"AI SDK 初始化成功!", Color.Green);
            }



            for (int i = 0; i < GlobalVariables.GConst.STATION_COUNT; i++)
            {
                m_HIKCameraControl[i] = new HIKCameraControl($"CCD{i+1}");
                if(i==0)
                {
                    returnValue = m_HIKCameraControl[i].Initial();
                    if (returnValue != ERROR_OK)
                    {

                        Log.Add($"CCD{i + 1}初始化失败!", Color.Red);

                    }
                    else
                    {

                        Log.Add($"CCD{i + 1}初始化成功!", Color.Green);

                    }
                }
                else
                {
                    
                }
                
                
                m_ActionRunThread[i] = new ActionRunThread(m_HIKCameraControl[i], m_SiemensPLCControl);
               
                m_AIRunThread[i] = new AIRunThread(m_HIKCameraControl[i], m_SaveImageThread, m_AISDKManage,m_SiemensPLCControl);
                //m_ConnectHeartbeatThreads[i] = new ConnectHeartbeatThread(m_HIKCameraControl[i],m_SiemensPLCControl);
            }

            m_ActionRunThread[0].m_sendProduct = ProductRecive1;
            m_ActionRunThread[1].m_sendProduct = ProductRecive2;
            //产品型号
            //Console.WriteLine(AppDomain.CurrentDomain.BaseDirectory + "\\Model\\productModel.csv");
            CSV.Instance[0].Read(AppDomain.CurrentDomain.BaseDirectory + "\\Model\\productModel.csv");
            int index=CSV.Instance[0].Data.FindIndex(r => r.Contains($"{XMLConfig.Device.Items[0].ProductModel}"));
            //加载产品组别
            if(index!=-1) CSV.Instance[1].Read(AppDomain.CurrentDomain.BaseDirectory + $"\\Content\\{CSV.Instance[0].Data[index][1]}.csv");

            //产品组别
            if (CSV.Instance[1].Data.Count < int.Parse(XMLConfig.Device.Items[0].EquipmentNumber))
            {
                MessageBox.Show("超过产品组别最大数");
                return;
            }
            List<string> m_list = CSV.Instance[1].Data[int.Parse(XMLConfig.Device.Items[0].EquipmentNumber)];
            string resText = m_list[2] + m_list[1] + DateTime.Now.ToString("MMdd") + m_list[3];
            smInfoWindow1.EquipmentNumber = XMLConfig.Device.Items[0].EquipmentNumber + ";" + resText;



            //取出组别信息
            //List<string> m_list = CSV.Instance[1].Data[int.Parse(XMLConfig.Device.Items[0].EquipmentNumber)];
            //string resText = CSV.Instance[1].Data[0][0]+";"+m_list[0]+";" +m_list[2]+m_list[1]+DateTime.Now.ToString("MMdd")+m_list[3];



            returnValue = m_SiemensPLCControl.Initial();
            if (returnValue != ERROR_OK)
            {
                Log.Add($"PLC初始化失败!", Color.Red);
                //return;
            }
            else
            {
                Log.Add($"PLC初始化成功!", Color.Green);

               // //获取当前型号
               // ushort returnProNum = m_SiemensPLCControl.ReadUshort("DB89.60.0");
               // Log.Add($"当前型号{returnProNum}!", Color.Green);
               //// 获取当前组别
               // ushort returnGroup = m_SiemensPLCControl.ReadUshort("DB89.62.0");
               // Log.Add($"当前组别{returnGroup}!", Color.Green);

               // //型号信息
               // string Temp = CSV.Instance[0].Data[returnProNum+ 1][1];
               // SMLogWindow.OutLog($"Model:{Temp}", Color.Green);
               // XMLConfig.Device.Items[0].ProductModel = Temp;
               // smInfoWindow1.ProductModel = XMLConfig.Device.Items[0].ProductModel;

                //
                //int index11 = CSV.Instance[0].Data.FindIndex(r => r.Contains($"{XMLConfig.Device.Items[0].ProductModel}"));
                //if (File.Exists(AppDomain.CurrentDomain.BaseDirectory + $"\\Content\\{CSV.Instance[0].Data[index11][1]}.csv"))
                //{
                //    //加载产品组别
                //    if (index11 != -1) CSV.Instance[1].Read(AppDomain.CurrentDomain.BaseDirectory + $"\\Content\\{CSV.Instance[0].Data[index11][1]}.csv");

                //    //组别
                //    XMLConfig.Device.Items[0].EquipmentNumber = returnGroup.ToString();

                //    List<string> m_list11 = CSV.Instance[1].Data[int.Parse(XMLConfig.Device.Items[0].EquipmentNumber)];
                //    string resText11 = m_list11[2] + m_list11[1] + DateTime.Now.ToString("MMdd") + m_list11[3];
                //    smInfoWindow1.EquipmentNumber = XMLConfig.Device.Items[0].EquipmentNumber + ";" + resText11;
                //    SMLogWindow.OutLog($"group:{smInfoWindow1.EquipmentNumber}", Color.Green);
                //}
                //else
                //{
                //    MessageBox.Show($"本地不存在{CSV.Instance[0].Data[index11][1]}刻字信息");
                //    smInfoWindow1.EquipmentNumber = "null";
                //}
               

                //发送相机ready信号
                m_SiemensPLCControl.WriteBool("DB89.0.0", true);
            }


            smInfoWindow1.AddConfig(XMLConfig);

            smButtonRun.Enabled = true;

            smButtonOCR.Enabled = true;

            #region plc_ready
            ////CCD15 ready信号
            //returnValue = m_SiemensPLCControl.WriteBool("DB2000.0.1", true);
            //if (returnValue != ERROR_OK)
            //{
            //    Log.Add($"CCD15 PC->PLC Ready 信号失败!", Color.Red);
            //    return;
            //}
            //else
            //{
            //    Log.Add($"CCD15 PC->PLC Ready 信号成功!", Color.Green);
            //}

            ////CCD17 ready信号
            //returnValue = m_SiemensPLCControl.WriteBool("DB2000.8.1", true);
            //if (returnValue != ERROR_OK)
            //{
            //    Log.Add($"CCD17 PC->PLC Ready 信号失败!", Color.Red);
            //    return;
            //}
            //else
            //{
            //    Log.Add($"CCD17 PC->PLC Ready 信号成功!", Color.Green);
            //}

            #endregion

        }

        private void UpdateDevice(DeviceInfo devinfo)
        {

        }

        private void UpdateDevice()
        {
            InitialConfigFile();

            
           //新的型号加载
            int index = CSV.Instance[0].Data.FindIndex(r => r.Contains($"{XMLConfig.Device.Items[0].ProductModel}"));
            if (index == -1)
            {
                MessageBox.Show("加载型号信息报错");
                return;
            }

            //加载产品组别
            if (index != -1) CSV.Instance[1].Read(AppDomain.CurrentDomain.BaseDirectory + $"\\Content\\{CSV.Instance[0].Data[index][1]}.csv");

            //产品组别
            if (CSV.Instance[1].Data.Count< int.Parse(XMLConfig.Device.Items[0].EquipmentNumber))
            {
                MessageBox.Show("超过产品组别最大数");
                return;
            }
            List<string> m_list = CSV.Instance[1].Data[int.Parse(XMLConfig.Device.Items[0].EquipmentNumber)];
            string resText = m_list[2]+m_list[1]+DateTime.Now.ToString("MMdd")+m_list[3];
            smInfoWindow1.EquipmentNumber = XMLConfig.Device.Items[0].EquipmentNumber+";"+resText;
            return;

            if(InvokeRequired)
            {
                Invoke(new MethodInvoker(UpdateDevice));
                return;
            }
            //产品型号
            smInfoWindow1.ProductModel = XMLConfig.Device.Items[0].ProductModel;
            //设备编号
            smInfoWindow1.EquipmentNumber = XMLConfig.Device.Items[0].EquipmentNumber;
            //模型版本
            smInfoWindow1.ModelVersion = XMLConfig.Device.Items[0].ModelVer;
            //模型日期
            smInfoWindow1.ModelDate = XMLConfig.Device.Items[0].ModelDate;
            //当前批次号
            smInfoWindow1.BatchNumber = XMLConfig.Device.Items[0].CurBatch;
        }

        private void InitialControlArray()
        {
            try
            {
                int controlIndex = 0;
                foreach (Control control in tableLayoutPanelMainHome.Controls)
                {
                    if (control.Name.StartsWith("smImageWindow"))
                    {
                        controlIndex = Convert.ToInt32(control.Name.Substring(control.Name.Length - 1));
                        m_SMImageWindows[controlIndex] = (SMImageWindow)control;
                        m_SMImageWindows[controlIndex].Tag = controlIndex;
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"{ex.ToString()}", "提示!!!", MessageBoxButtons.OKCancel, MessageBoxIcon.Error);
            }
        }

        private int InitialConfigFile()
        {
            int returnValue = XMLConfigParse.DeserializeFromXml<XMLConfigParse>(ConfigFilePath, ref XMLConfig, ref ErrorInfo);
            if (returnValue != XMLConfigParse.ErrorOK)
            {
                return returnValue;
            }

            returnValue = XMLConfig.GenerateNodeInfo();
            if (returnValue != XMLConfigParse.ErrorOK)
            {
                return returnValue;
            }
            return ERR_OK;
        }

        private void smButtonRun_BtnClick(object sender, EventArgs e)
        {
            if (!BtnRunState)
            {
                smButtonRun.BtnImage = global::SmoreVision.Properties.Resources.auto_on;
                smImageWindow1.ShowManualButton = false;
                //smImageWindow2.ShowManualButton = false;
                for (int i = 0; i < GlobalVariables.GConst.STATION_COUNT; i++)
                {
                    m_ActionRunThread[i].StartThread();
                    m_AIRunThread[i].StartThread();
                    //m_ConnectHeartbeatThreads[i].StartThread();
                    if (i == 1) continue;
                    m_AIRunThread[i].m_ShowImage += m_SMImageWindows[i+1].ImageShow;
                    m_AIRunThread[i].m_ShowResult += m_SMImageWindows[i+1].ResultShow;
                    //m_ConnectHeartbeatThreads[i].m_ShowHeartColor += m_SMImageWindows[i+1].HeartResultShow;
                }
                m_SaveImageThread.StartThread();
            }
            else
            {
                smButtonRun.BtnImage = global::SmoreVision.Properties.Resources.auto_off;
                smImageWindow1.ShowManualButton = true;
                //smImageWindow2.ShowManualButton = true;
                for (int i = 0; i < GlobalVariables.GConst.STATION_COUNT; i++)
                {
                    m_ActionRunThread[i].Cycled = false;
                    m_AIRunThread[i].Cycled = false;
                    //m_ConnectHeartbeatThreads[i].Cycled = false;
                }
                m_SaveImageThread.Cycled = false;
            }
            BtnRunState = !BtnRunState;
        }

        /// <summary>
        /// CCD1手动推理单张图片
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void smImageWindow1_BtnRunSinglePicClick(object sender, EventArgs e)
        {
            try
            {
                SimplexTestTask("TSTM");
            }
            catch (Exception ex)
            {
                MessageBox.Show($"{ex.ToString()}", "提示!!!", MessageBoxButtons.OKCancel, MessageBoxIcon.Error);
            }
        }

        /// <summary>
        /// CCD1手动推理整个文件夹中的图片
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void smImageWindow1_BtnRunFolderPicClick(object sender, EventArgs e)
        {
            try
            {
                MultipleTestTask("TSTM");
            }
            catch (Exception ex)
            {
                MessageBox.Show($"{ex.ToString()}", "提示!!!", MessageBoxButtons.OKCancel, MessageBoxIcon.Error);
            }
        }

        /// <summary>
        /// CCD2手动推理单张图片
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void smImageWindow2_BtnRunSinglePicClick(object sender, EventArgs e)
        {
            try
            {
                //SimplexTestTask("OCR");
            }
            catch (Exception ex)
            {
                MessageBox.Show($"{ex.ToString()}", "提示!!!", MessageBoxButtons.OKCancel, MessageBoxIcon.Error);
            }
        }

        /// <summary>
        /// CCD2手动推理整个文件夹中的图片
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void smImageWindow2_BtnRunFolderPicClick(object sender, EventArgs e)
        {
            try
            {
                //MultipleTestTask("OCR");
            }
            catch (Exception ex)
            {
                MessageBox.Show($"{ex.ToString()}", "提示!!!", MessageBoxButtons.OKCancel, MessageBoxIcon.Error);
            }
        }

        /// <summary>
        /// 手动推理单张图片任务
        /// </summary>
        /// <param name="_taskName">CLS[进行分类算法推理]OCR[进行OCR算法推理]</param>
        private void SimplexTestTask(string _taskName)
        {
            int returnValue = 0;
            m_SaveImage = new SaveImage();
            OpenFileDialog dialog = new OpenFileDialog();
            dialog.Title = "请选择图片文件夹";
            dialog.Filter = "图片文件(*.jpg;*.png;*.bmp)|*.jpg;*.png;*.bmp";
            if (dialog.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                m_SaveImageThread.StartThread();

                Mat mat = Cv2.ImRead(dialog.FileName,ImreadModes.Unchanged);
                Mat srcMat = mat.Clone();
                string fileNameWithoutExtension = System.IO.Path.GetFileNameWithoutExtension(dialog.FileName);
                if (mat != null)
                {
                    SimplexTask = Task.Factory.StartNew(() =>
                    {

                        switch (_taskName)
                        {
                            case "TSTM":
                                {
                                    
                                    AlgoInput input;
                                    input.mat = mat.Clone();
                                    //if (3 != input.mat.Channels()) Cv2.CvtColor(mat, mat, ColorConversionCodes.GRAY2BGR);

                                    input.imgName = "123";
                                    input.productContent = @"{}";
                                    input.productModel = @"{}";

                                    AlgoOutput output;

                                    returnValue = m_AISDKManage.TSTMRun(input,out output);

                                    //Rootobject root = JsonConvert.DeserializeObject<Rootobject>(output.resJson);

                                    if (returnValue == ERR_FAILED)
                                    {
                                        SMLogWindow.OutLog("TSTM算法推理失败.", Color.Red);
                                    }
                                    else
                                    {
                                        SMLogWindow.OutLog($"TSTM算法推理成功.推理结果:{output.bRes}", Color.Green);
                                        if (smImageWindow1.InvokeRequired)
                                        {
                                            if (output.bRes)
                                            {
                                                BeginInvoke(new Action<bool>(smImageWindow1.ResultShow), true);
                                                SMDataWindow.AddData(true);
                                                smImageWindow1.ImageShow(SDKExtendClass.IOcrResponse.VisualizeMat(output.mask, Scalar.LightGreen, "OK"));
                                                
                                                //存图
                                                m_SaveImage.stationName = "CCD1";
                                                m_SaveImage.picture = srcMat;
                                                m_SaveImage.result = true;
                                                m_SaveImage.mask = SDKExtendClass.IOcrResponse.VisualizeMat(output.mask, Scalar.LightGreen, "OK");
                                                m_SaveImage.time = DateTime.Now.ToString(GlobalVariables.GConst.IMAGE_SAVE_BASE_TIME_FORMAT);
                                                m_SaveImageThread.SaveImagePack_Buffer.Enqueue(m_SaveImage);
                                            }
                                            else
                                            {
                                                BeginInvoke(new Action<bool>(smImageWindow1.ResultShow), false);
                                                SMDataWindow.AddData(false);
                                                smImageWindow1.ImageShow(SDKExtendClass.IOcrResponse.VisualizeMat(output.mask, Scalar.Red, "NG"));
                                                

                                                //存图
                                                m_SaveImage.stationName = "CCD1";
                                                m_SaveImage.picture = srcMat;
                                                m_SaveImage.result = false;
                                                m_SaveImage.mask = SDKExtendClass.IOcrResponse.VisualizeMat(output.mask, Scalar.Red, "NG");
                                                m_SaveImage.time = DateTime.Now.ToString(GlobalVariables.GConst.IMAGE_SAVE_BASE_TIME_FORMAT);
                                                m_SaveImageThread.SaveImagePack_Buffer.Enqueue(m_SaveImage);
                                            }
                                        }
                                       
                                    }
                                }
                                break;
                            default:
                                break;
                        }
                        Thread.Sleep(1);
                        m_SaveImageThread.Cycled = false;
                    });
                }
            }
        }

        /// <summary>
        /// 手动推理整个文件夹中的图片
        /// </summary>
        /// <param name="_taskName"></param>
        private void MultipleTestTask(string _taskName)
        {
            FileInfo[] m_files;
            m_SaveImage = new SaveImage();
            FolderBrowserDialog dlg = new FolderBrowserDialog();
            dlg.Description = "请选择图像文件夹";
            if (dlg.ShowDialog() == DialogResult.OK)
            {
                m_SaveImageThread.StartThread();

                DirectoryInfo dir = new DirectoryInfo(dlg.SelectedPath);
                m_files = dir.GetFiles($"*.*", SearchOption.AllDirectories).Where(s => s.Name.EndsWith("jpg") || s.Name.EndsWith("png") || s.Name.EndsWith("bmp")).ToArray();
                if (m_files.Length > 0)
                {
                    MultipleTask = Task.Factory.StartNew(() =>
                    {
                        MultipleTaskRun = true;
                        int iIndex = 0;
                        while (MultipleTaskRun)
                        {
                            Mat mat = new Mat(m_files[iIndex].FullName,ImreadModes.Unchanged);
                            Mat srcMat = mat.Clone();
                            switch (_taskName)
                            {
                                case "TSTM":
                                    {
                                        AlgoInput input;
                                        input.mat = mat.Clone();
                                        input.imgName = "123";
                                        input.productContent = @"{}";
                                        input.productModel = @"{}";

                                        AlgoOutput output;

                                        returnValue = m_AISDKManage.TSTMRun(input, out output);

                                        //Rootobject root = JsonConvert.DeserializeObject<Rootobject>(output.resJson);

                                        if (returnValue == ERR_FAILED)
                                        {
                                            SMLogWindow.OutLog("TSTM算法推理失败.", Color.Red);
                                        }
                                        else
                                        {
                                            SMLogWindow.OutLog($"TSTM算法推理成功.推理结果:{output.bRes}", Color.Green);
                                            if (smImageWindow1.InvokeRequired)
                                            {
                                                if (output.bRes)
                                                {
                                                    BeginInvoke(new Action<bool>(smImageWindow1.ResultShow), true);
                                                    SMDataWindow.AddData(true);
                                                    smImageWindow1.ImageShow(SDKExtendClass.IOcrResponse.VisualizeMat(output.mask, Scalar.LightGreen, "OK"));



                                                    //存图
                                                    m_SaveImage.stationName = "CCD1";
                                                    m_SaveImage.picture = srcMat;
                                                    m_SaveImage.result = true;
                                                    m_SaveImage.mask = SDKExtendClass.IOcrResponse.VisualizeMat(output.mask, Scalar.LightGreen, "OK");
                                                    m_SaveImage.time = DateTime.Now.ToString(GlobalVariables.GConst.IMAGE_SAVE_BASE_TIME_FORMAT);
                                                    m_SaveImageThread.SaveImagePack_Buffer.Enqueue(m_SaveImage);
                                                }
                                                else
                                                {
                                                    BeginInvoke(new Action<bool>(smImageWindow1.ResultShow), false);
                                                    SMDataWindow.AddData(false);
                                                    smImageWindow1.ImageShow(SDKExtendClass.IOcrResponse.VisualizeMat(output.mask, Scalar.Red, "NG"));


                                                    //存图
                                                    m_SaveImage.stationName = "CCD1";
                                                    m_SaveImage.picture = srcMat;
                                                    m_SaveImage.result = false;
                                                    m_SaveImage.mask = SDKExtendClass.IOcrResponse.VisualizeMat(output.mask, Scalar.Red, "NG");
                                                    m_SaveImage.time = DateTime.Now.ToString(GlobalVariables.GConst.IMAGE_SAVE_BASE_TIME_FORMAT);
                                                    m_SaveImageThread.SaveImagePack_Buffer.Enqueue(m_SaveImage);
                                                }
                                            }

                                        }
                                    }
                                    break;
                                default:
                                    break;
                            }
                            iIndex++;
                            if (iIndex >= m_files.Length)
                                break;
                            Thread.Sleep(10);
                        }
                        Thread.Sleep(1000);
                        m_SaveImageThread.Cycled = false;
                    });
                }
            }
        }

        private void panel3_Paint(object sender, PaintEventArgs e)
        {
          
        }

        /// <summary>
        /// CCD1手动触发
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void smImageWindow1_TriggerCamera(object sender, EventArgs e)
        {
            if (m_HIKCameraControl[0] != null)
            {
                int returnValue = m_HIKCameraControl[0].SoftWareTriggerOnce();
                if (returnValue != ERROR_OK)
                {
                    SMLogWindow.OutLog($"CCD{m_HIKCameraControl[0].CCDName}触发失败.", Color.Red);
                }
                else
                {
                    SMLogWindow.OutLog($"CCD{m_HIKCameraControl[0].CCDName}触发成功.", Color.Green);
                    Thread.Sleep(1000);
                    if (!m_HIKCameraControl[0].cameraImageCallPack_Buffer.IsEmpty)
                    {
                        CameraImageCallPack cameraImageCallPack = new CameraImageCallPack();
                        m_HIKCameraControl[0].cameraImageCallPack_Buffer.TryDequeue(out cameraImageCallPack);
                        //SimplexTrrigerTask("TSTM", cameraImageCallPack.picture);

                        smImageWindow1.ImageShow(SDKExtendClass.IOcrResponse.VisualizeMat(cameraImageCallPack.picture, Scalar.LightGreen, "OK"));
                        //smImageWindow1.ImageShow(SDKExtendClass.IOcrResponse.VisualizeMat(mask, Scalar.Red, "NG"));
                    }
                }
            }
            else
            {
                SMLogWindow.OutLog("CCD15没有初始化.", Color.Red);
            }
        }

        /// <summary>
        /// CCD2手动触发
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void smImageWindow2_TriggerCamera(object sender, EventArgs e)
        {
            if (m_HIKCameraControl[1] != null)
            {
                int returnValue = m_HIKCameraControl[1].SoftWareTriggerOnce();
                if (returnValue != ERROR_OK)
                {
                    SMLogWindow.OutLog("CCD17触发失败.", Color.Red);
                }
                else
                {
                    SMLogWindow.OutLog("CCD17触发成功.", Color.Green);
                    Thread.Sleep(1000);
                    if (!m_HIKCameraControl[1].cameraImageCallPack_Buffer.IsEmpty)
                    {
                        CameraImageCallPack cameraImageCallPack = new CameraImageCallPack();
                        m_HIKCameraControl[1].cameraImageCallPack_Buffer.TryDequeue(out cameraImageCallPack);
                        SimplexTrrigerTask("OCR", cameraImageCallPack.picture);
                    }
                }
            }
            else
            {
                SMLogWindow.OutLog("CCD17没有初始化.",Color.Red);
            }
        }

        /// <summary>
        /// 关闭窗体
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void FormMain_FormClosed(object sender, FormClosedEventArgs e)
        {
            //关闭相机
            for (int i = 0; i < GlobalVariables.GConst.STATION_COUNT; i++)
            {
                if (m_HIKCameraControl[i] != null)
                {
                    m_HIKCameraControl[i].DeInitial();
                }
            }
            //关闭PLC
            if (m_SiemensPLCControl != null)
            {
                m_SiemensPLCControl.DeInitial();
            }
        }

        private void smDataWindow1_ClearData(object sender, EventArgs e)
        {
            smImageWindow1.ClearProduceData();
            //smImageWindow2.ClearProduceData();
        }

        /// <summary>
        /// 手动触发相机推理单张图片任务
        /// </summary>
        /// <param name="_taskName">CLS[进行分类算法推理]OCR[进行OCR算法推理]</param>
        private void SimplexTrrigerTask(string _taskName,Mat mat)
        {
            int returnValue = 0;
            m_SaveImage = new SaveImage();
            Mat srcMat = mat.Clone();
            if (mat != null)
            {
                SimplexTrigerTask = Task.Factory.StartNew(() =>
                {

                    switch (_taskName)
                    {
                        case "CLS":
                            {
                                string clsResult = "";
                                returnValue = Error_OK; //m_AISDKManage.CLSRun(mat, ref clsResult);
                                if (returnValue != Error_OK)
                                {
                                    SMLogWindow.OutLog("CLS算法推理失败.", Color.Red);
                                }
                                else
                                {
                                    if (clsResult != "")
                                    {
                                        SMLogWindow.OutLog($"CLS算法推理成功.推理结果:{clsResult}", Color.Green);
                                        if (smImageWindow1.InvokeRequired)
                                        {
                                            if (clsResult.Contains("OK"))
                                            {
                                                BeginInvoke(new Action<bool>(smImageWindow1.ResultShow), true);
                                                SMDataWindow.AddData(true);
                                                smImageWindow1.ImageShow(SDKExtendClass.IOcrResponse.VisualizeMat(mat, Scalar.LightGreen, "OK"));

                                                //存图
                                                m_SaveImage.stationName = "CCD1";
                                                m_SaveImage.picture = srcMat;
                                                m_SaveImage.result = true;
                                                m_SaveImage.mask = SDKExtendClass.IOcrResponse.VisualizeMat(mat, Scalar.LightGreen, "OK");
                                                m_SaveImage.time = DateTime.Now.ToString(GlobalVariables.GConst.IMAGE_SAVE_BASE_TIME_FORMAT);
                                                m_SaveImageThread.SaveImagePack_Buffer.Enqueue(m_SaveImage);
                                            }
                                            else
                                            {
                                                BeginInvoke(new Action<bool>(smImageWindow1.ResultShow), false);
                                                SMDataWindow.AddData(false);
                                                smImageWindow1.ImageShow(SDKExtendClass.IOcrResponse.VisualizeMat(mat, Scalar.Red, "NG"));

                                                //存图
                                                m_SaveImage.stationName = "CCD1";
                                                m_SaveImage.picture = srcMat;
                                                m_SaveImage.result = false;
                                                m_SaveImage.mask = SDKExtendClass.IOcrResponse.VisualizeMat(mat, Scalar.Red, "NG");
                                                m_SaveImage.time = DateTime.Now.ToString(GlobalVariables.GConst.IMAGE_SAVE_BASE_TIME_FORMAT);
                                                m_SaveImageThread.SaveImagePack_Buffer.Enqueue(m_SaveImage);
                                            }
                                        }

                                    }
                                    else
                                    {
                                        SMLogWindow.OutLog($"CLS算法推理失败.推理结果为:NULL", Color.Red);
                                    }
                                }
                            }
                            break;
                        default:
                            break;
                    }
                });
            }
        }

        private void ProductRecive1(ProductInfo proinfo)
        {
            SMLogWindow.OutLog($"Model:{proinfo.Product_Model};Content:{proinfo.Product_content}.", Color.Green);

            
            //组别
            XMLConfig.Device.Items[0].EquipmentNumber = proinfo.Product_content;

            if (CSV.Instance[1].Data.Count> int.Parse(XMLConfig.Device.Items[0].EquipmentNumber))
            {
                List<string> m_list = CSV.Instance[1].Data[int.Parse(XMLConfig.Device.Items[0].EquipmentNumber)];
                string resText = m_list[2] + m_list[1] + DateTime.Now.ToString("MMdd") + m_list[3];
                smInfoWindow1.EquipmentNumber = XMLConfig.Device.Items[0].EquipmentNumber + ";" + resText;
            }
            else
            {
                SMLogWindow.OutLog($"当前组别索引:{int.Parse(XMLConfig.Device.Items[0].EquipmentNumber)};最大索引:{CSV.Instance[1].Data.Count}",Color.Red);
                XMLConfig.Device.Items[0].EquipmentNumber = "0";
                smInfoWindow1.EquipmentNumber = "null";
            }

           

        }
        private void ProductRecive2(ProductInfo proinfo)
        {
            SMLogWindow.OutLog($"Model:{proinfo.Product_Model};Content:{proinfo.Product_content}.", Color.Green);

            //型号信息
            string Temp = CSV.Instance[0].Data[int.Parse(proinfo.Product_Model)+1][1];
            SMLogWindow.OutLog($"Model:{Temp}",Color.Green);
            XMLConfig.Device.Items[0].ProductModel = Temp;
            smInfoWindow1.ProductModel = XMLConfig.Device.Items[0].ProductModel;
            if(File.Exists(AppDomain.CurrentDomain.BaseDirectory + $"\\Content\\{Temp}.csv"))
            {
                //加载产品组别
                CSV.Instance[1].Read(AppDomain.CurrentDomain.BaseDirectory + $"\\Content\\{Temp}.csv");
            }
            else
            {
                MessageBox.Show($"不存在{Temp}刻字信息");
            }
           
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if(this.smImageWindow1.Visible)
            {
                this.tableLayoutPanelMainHome.ColumnStyles[0].Width = 2F;
                this.tableLayoutPanelMainHome.ColumnStyles[1].Width = 98F;
            }
            else
            {
                this.tableLayoutPanelMainHome.ColumnStyles[0].Width = 50F;
                this.tableLayoutPanelMainHome.ColumnStyles[1].Width = 50F;
            }
            this.smImageWindow1.Visible = !this.smImageWindow1.Visible;
        }

        private void smButton1_BtnClick(object sender, EventArgs e)
        {

            if (!BtnOCRState)
            {
                smButtonOCR.BtnImage = global::SmoreVision.Properties.Resources.auto_on;
                XMLConfig.SDK.Items[0].RunEnable = true;
            }
            else
            {
                smButtonOCR.BtnImage = global::SmoreVision.Properties.Resources.auto_off;
                XMLConfig.SDK.Items[0].RunEnable = false;
            }
            BtnOCRState = !BtnOCRState;
            
        }

        private void label1_Click(object sender, EventArgs e)
        {
          


        }
    }
}
